const exec = require('child_process').exec;
exec('code-push-server',(err,res)=>{});